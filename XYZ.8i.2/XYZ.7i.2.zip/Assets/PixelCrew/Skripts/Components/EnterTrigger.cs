using UnityEngine;
using UnityEngine.Events;


namespace Assets.Scripts.Components
{
    public class EnterTrigger : MonoBehaviour
    {
        [SerializeField] private string _tag;
        [SerializeField] private UnityEvent _action;


        private void OnTriggerEnter2D(Collider2D other)
        {
           if (other.gameObject.CompareTag(_tag))
           {
                Debug.Log("��������");
                _action?.Invoke();
           }
        }

    }
}
using System.Collections;
using UnityEngine;

namespace Assets.PixelCrew
{
    public class HandlesUtils : MonoBehaviour
    {
        public static readonly Color TransparentRed = new Color(1f, 0f, 0f, 0.1f);
        public static readonly Color TransparentGreen = new Color(0f, 1f, 0f, 0.1f);
    }
}